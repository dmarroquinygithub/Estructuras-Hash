﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistroVacunasDictionary
{
    internal class Persona
    {
        public string CUI { get; set; }
        public string Nombre { get; set; }
        public string Vacuna { get; set; }

        public Persona(string cui, string nombre, string vacuna)
        {
            CUI = cui;
            Nombre = nombre;
            Vacuna = vacuna;
        }
    }
}

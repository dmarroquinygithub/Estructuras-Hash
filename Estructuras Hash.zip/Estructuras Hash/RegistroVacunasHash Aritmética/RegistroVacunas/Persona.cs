﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistroVacunas
{
    internal class Persona
    {
        public string CUI { get; set; }
        public string Nombre { get; set; }

        public List<Vacuna> vacunas = new List<Vacuna>();
    }
}

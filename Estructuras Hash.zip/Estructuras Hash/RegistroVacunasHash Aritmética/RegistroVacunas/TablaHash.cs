﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistroVacunas
{
    internal class TablaHash
    {
        private List<Persona>[] tabla;
        private int tamaño = 10;

        public TablaHash()
        {
            tabla = new List<Persona>[tamaño];

            for (int i = 0; i < tamaño; i++)
            {
                tabla[i] = new List<Persona>();
            }
        }

        private int FuncionHash(long cui)
        {
            return (int)(cui % tamaño);
        }

        public void Insertar(Persona persona)
        {
            int indice = FuncionHash(long.Parse(persona.CUI));
            tabla[indice].Add(persona);
        }

        public Persona Buscar(string cui)
        {
            int indice = FuncionHash(long.Parse(cui));

            foreach (var persona in tabla[indice])
            {
                if (persona.CUI == cui)
                {
                    return persona;
                }
            }

            return null;
        }

        public List<Persona>[] ObtenerTabla()
        {
            return tabla;
        }
    }
}

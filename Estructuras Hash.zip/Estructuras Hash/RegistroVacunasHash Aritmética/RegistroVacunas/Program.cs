﻿using System;
using System.Collections.Generic;

namespace RegistroVacunas
{
    class Program
    {
        static void Main(string[] args)
        {
            TablaHash tabla = new TablaHash();
            Dictionary<string, Persona> diccionario = new Dictionary<string, Persona>();

            List<Persona> personas = Archivo.Leer();

            foreach (var p in personas)
            {
                tabla.Insertar(p);
                diccionario[p.CUI] = p;
            }

            int opcion = 0;

            while (opcion != 3)
            {
                Console.WriteLine(" REGISTRO DE VACUNAS UMG JALAPA ");
                Console.WriteLine("1. Buscar persona por CUI");
                Console.WriteLine("2. Registrar vacuna");
                Console.WriteLine("3. Salir y guardar");

                opcion = int.Parse(Console.ReadLine());

                if (opcion == 1)
                {
                    Console.WriteLine("Ingresa el CUI:");
                    string cui = Console.ReadLine();

                    Persona persona = tabla.Buscar(cui);

                    if (persona == null)
                    {
                        Console.WriteLine("No existe la persona");
                    }
                    else
                    {
                        Console.WriteLine("Nombre: " + persona.Nombre);
                        Console.WriteLine("CUI: " + persona.CUI);
                        Console.WriteLine("Vacunas registradas:");

                        foreach (var v in persona.vacunas)
                        {
                            Console.WriteLine(v.vacuna + " - " + v.fecha);
                        }
                    }
                }

                if (opcion == 2)
                {
                    Console.WriteLine("Ingresa el CUI:");
                    string cui = Console.ReadLine();

                    Persona persona;

                    if (diccionario.ContainsKey(cui))
                    {
                        persona = diccionario[cui];
                    }
                    else
                    {
                        persona = new Persona();

                        persona.CUI = cui;

                        Console.WriteLine("Ingresa nombre:");
                        persona.Nombre = Console.ReadLine();

                        diccionario[cui] = persona;
                        tabla.Insertar(persona);
                    }

                    Vacuna vacuna = new Vacuna();

                    Console.WriteLine("Nombre de vacuna:");
                    vacuna.vacuna = Console.ReadLine();

                    Console.WriteLine("Fecha:");
                    vacuna.fecha = Console.ReadLine();

                    persona.vacunas.Add(vacuna);

                    Console.WriteLine("Nombre: " + persona.Nombre);
                    Console.WriteLine("CUI: " + persona.CUI);

                    Console.WriteLine("Vacuna registrada");
                }
            }

            Archivo.Guardar(new List<Persona>(diccionario.Values));
        }
    }
}

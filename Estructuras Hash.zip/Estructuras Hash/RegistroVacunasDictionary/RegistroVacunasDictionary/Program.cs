﻿using System;
using System.Collections.Generic;
using System.IO;

namespace RegistroVacunasDictionary
{
    class Program
    {
        static Dictionary<string, Persona> registro = new Dictionary<string, Persona>();

        static string archivo = "vacunas.txt";

        static void Main(string[] args)
        {
            CargarArchivo();

            int opcion = 0;

            do
            {
                Console.WriteLine(" REGISTRO DE VACUNAS UMG Dictionary");
                Console.WriteLine("1. Registrar persona");
                Console.WriteLine("2. Buscar por CUI");
                Console.WriteLine("3. Salir y guardar");

                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        RegistrarPersona();
                        break;

                    case 2:
                        BuscarPersona();
                        break;
                }

            } while (opcion != 3);
        }

        static void RegistrarPersona()
        {
            Console.Write("Ingrese CUI: ");
            string cui = Console.ReadLine();

            Console.Write("Ingrese nombre: ");
            string nombre = Console.ReadLine();

            Console.Write("Ingrese vacuna: ");
            string vacuna = Console.ReadLine();

            Persona persona = new Persona(cui, nombre, vacuna);

            registro[cui] = persona;

            GuardarArchivo();

            Console.WriteLine("Persona registrada.");
        }

        static void BuscarPersona()
        {
            Console.Write("Ingrese CUI a buscar: ");
            string cui = Console.ReadLine();

            if (registro.ContainsKey(cui))
            {
                Persona p = registro[cui];

                Console.WriteLine("Persona encontrada:");
                Console.WriteLine("Nombre: " + p.Nombre);
                Console.WriteLine("Vacuna: " + p.Vacuna);
            }
            else
            {
                Console.WriteLine("No existe esa persona.");
            }
        }

        static void GuardarArchivo()
        {
            StreamWriter writer = new StreamWriter(archivo);

            foreach (var persona in registro.Values)
            {
                writer.WriteLine(persona.CUI + "," + persona.Nombre + "," + persona.Vacuna);
            }

            writer.Close();
        }

        static void CargarArchivo()
        {
            if (File.Exists(archivo))
            {
                string[] lineas = File.ReadAllLines(archivo);

                foreach (string linea in lineas)
                {
                    string[] datos = linea.Split(',');

                    Persona persona = new Persona(datos[0], datos[1], datos[2]);

                    registro[persona.CUI] = persona;
                }
            }
        }
    }
}
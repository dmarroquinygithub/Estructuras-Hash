﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.Json;

namespace RegistroVacunas
{
    internal class Archivo
    {
        private static string ruta = "vacunas.txt";

        public static void Guardar(List<Persona> personas)
        {
            StreamWriter sw = new StreamWriter(ruta);

            foreach (var persona in personas)
            {
                string json = JsonSerializer.Serialize(persona.vacunas);
                sw.WriteLine(persona.CUI + "|" + persona.Nombre + ":" + json);
            }

            sw.Close();
        }

        public static List<Persona> Leer()
        {
            List<Persona> personas = new List<Persona>();

            if (!File.Exists(ruta))
                return personas;

            string[] lineas = File.ReadAllLines(ruta);

            foreach (var linea in lineas)
            {
                string[] partes = linea.Split(':', 2);

                string[] datosPersona = partes[0].Split('|');

                string cui = datosPersona[0];
                string nombre = datosPersona[1];


                string json = partes[1];

                List<Vacuna> vacunas = JsonSerializer.Deserialize<List<Vacuna>>(json);

                Persona persona = new Persona();
                persona.CUI = cui;
                persona.Nombre = nombre;
                persona.vacunas = vacunas;

                personas.Add(persona);
            }

            return personas;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistroVacunas
{
    internal class Vacuna
    {
        public string vacuna { get; set; }
        public string fecha { get; set; }
    }
}
